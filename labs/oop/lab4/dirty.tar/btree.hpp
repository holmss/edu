#ifndef TTREE_H
#define TTREE_H

#include "pentagon.hpp"
#include <iostream>
#include <memory>

template <class T>
class TTree
{
public:
  TTree();
  TTree(const TTree &orig);
  virtual ~TTree();

  Pentagon getItem();
  Pentagon getItem(char *path);


  void add(std::shared_ptr<T>);
  void Remove(std::shared_ptr<TTree<T>> *node);

  std::shared_ptr<TTree<T> > * get(char *path);
  int height() const;
  bool empty();

  template <class A> friend std::ostream &operator<<(std::ostream &os, const TTree<A> &tree);

  std::shared_ptr<Pentagon> value;
  std::shared_ptr<TTree <T> > *left;
  std::shared_ptr<TTree <T> > *right;
  std::shared_ptr<TTree <T> > *prev;
};

#endif // TTREE_H
