#!/bin/bash
#clear old tests
rm tmp
rm -rf tests/
mkdir tests
#compile cheker
cd Bm
make
cd ..
#compile cheker
cd Generator
make
rm -rf tests/
mkdir tests
./gen 10000 5
mv tests/*test* ../tests
cd ..
#compile Lab4
cd Lab
make
make clear
cd ..

echo "Generate tests"
for test_file in `ls tests/*.t`; do

    if ! ./Bm/Bm < $test_file > "${test_file%.*}.a" ; then
        echo "ERROR"
        continue
    fi 
done

echo "Execute tests"
for test_file in `ls tests/*.t`; do
    if ! ./Lab/Lab < $test_file > tmp ; then
        echo "ERROR"
        continue
    fi
    answer_file="${test_file%.*}"

    if ! diff -u "${answer_file}.a" tmp ; then
        echo "Failed ${test_file%.*}"
    #else
        #echo "OK"
    fi 
done
echo "All tests executed"
