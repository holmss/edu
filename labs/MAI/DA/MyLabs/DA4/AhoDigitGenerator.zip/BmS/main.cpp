#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <map>
#include <deque>
#include <vector>


typedef struct STposition{
    int line;
    int row;
} TPosition;
TPosition nowWord = {1, 1};


void PreBmBc(std::vector<std::pair<std::string, int> > &pattern, std::vector<int>& array) {
    int i;
    for (i = 0; i < array.size(); ++i) {
        array[i] = pattern.size();
    }
    for (i = 0; i < pattern.size() - 1; ++i) {
        array[pattern[i].second] = pattern.size() - 1 - i;
    }
}


void BuildZblocks(const std::vector<std::pair<std::string, int > >& pattern, std::vector<int>& N) {
    int n = pattern.size();
    int lhs = 0;
    int rhs = 0;
    N[0] = 0;
    for (int i = 1; i < n; i++) {
        if (i <= rhs) {
            N[i] = std::min(rhs - i, N[i-lhs]);
        }
        while (i + N[i] < n && pattern[N[i]].first == pattern[i+N[i]].first) {
            N[i]+=1;
        }
        if (i + N[i] - 1 > rhs) {
            lhs = i;
            rhs = i + N[i];
        }
    }
}

void BuildNblock(const std::vector<std::pair<std::string, int > > &pattern, std::vector<int>& N) {
    for (int i  = pattern.size() - 2, l = pattern.size() - 1, r = pattern.size() - 1; i >= 0; --i) {
        if (i >= l) {
            N[i] = std::min((int)(i - l + 1), N[pattern.size() - 1 - r + i]);
        }

        while (i - N[i] >= 0 && pattern[pattern.size() - 1 - N[i]].first == pattern[i - N[i]].first) {
            ++N[i];
        }

        if (i - N[i] + 1 < l) {
            l = i - N[i] + 1;
            r = i;
        }
    }
}

void BuildLblock(std::vector<int>& L, const std::vector<int>& N) {
    for (int j = 0; j < L.size()-1; j++) {
        L[L.size()-N[j]] = j+1;
    }
}
void BuildlBlock(std::vector<int>& l, const std::vector<int>& N) {
    l[N.size()] = 0;
    for(int i = N.size()-1; i >= 0; i--) {
        int  j = N.size() - i;
        if (N[j] == j+1) {
            l[i] = j+1;
        }
        else {
            l[i] = l[i+1];
        }
    }
}

void PatternParsing(std::map<std::string, int> &patternDict,
                    std::vector<std::pair<std::string, int> >& allWordPattern);

bool TextParsing(std::deque<std::pair <std::string, TPosition> >&, const int &);
int main() {
    std::map<std::string, int> patternDict;
    std::vector<std::pair<std::string, int > > pattern;
    PatternParsing(patternDict, pattern);
    int patternSize = pattern.size();
    std::deque<std::pair <std::string, TPosition> > text;
    bool flag = TextParsing(text, patternSize);
    if (patternSize == 1) {
        while(flag) {
            if (pattern[0].first == text[0].first) {
            //text.size = 1 because pattern.size == 1
                printf("%d, %d\n", text[0].second.line, text[0].second.row);
            }
            flag = TextParsing(text, patternSize);
        }
        return 0;
    }
    //pattern size > 1
    std::vector<int> N(patternSize, 0);
    std::vector<int> array(patternDict.size());
    std::vector<int> l(patternSize+1, 0);
    std::vector<int> L(patternSize, 0);
    /* Preprocessing */
    PreBmBc(pattern, array);
    BuildNblock(pattern, N);
    BuildLblock(L, N);
    BuildlBlock(l, N);
    while(flag) {
        int i;
        int shift;
        for(i = patternSize - 1; i >= 0 && pattern[i].first == text[i].first; --i) {
        }
        if(i == -1) {
            printf("%d, %d\n", text[0].second.line, text[0].second.row);
            shift = patternSize - l[1];
        } else {
            int bc = -1;
            std::map<std::string, int>::iterator it = patternDict.find(text[i].first);
            if (it != patternDict.end()) {
                bc = it->second;
            }

            if(bc == -1) {
                bc = patternSize;
            } else {
                bc = array[bc] - (patternSize - 1 - i);
            }
            int lShift;
            if(i == patternSize - 1) {
                lShift = 1;
            } else {
                lShift = L[i + 1] > 0 ? patternSize - 1 - L[i + 1] : patternSize - 1 - l[i + 1];
            }
            if(lShift == 0) {
                lShift = 1;
            }
            shift = std::max(bc, lShift);
        }
        flag = TextParsing(text, shift);
    }
    return 0;


}

bool TextParsing(std::deque<std::pair<std::string, TPosition> >& text, const int & countNext) {
    int sizePattern = countNext;
    if (text.size()) {
        sizePattern = text.size();
        for(int i = countNext; i > 0; --i) {
            text.pop_front();
        }
    }
    text.resize(sizePattern);
    char ch;
    int i = sizePattern - countNext;
    while(i < sizePattern) {
        while(!isdigit(ch = getchar())) {
            if(ch == EOF) {
                return false;
            }
            if (ch == '\n') {
                ++nowWord.line;
                nowWord.row = 1;
            }
        }
        text[i].first += ch;
        while(isdigit(ch = getchar())) {
            text[i].first += ch;
        }
        text[i].second = nowWord;
        if (ch == ' ') {
            nowWord.row++;
        }
        std::ungetc(ch, stdin);
        ++i;
    }
    return true;

}

void PatternParsing(std::map<std::string, int> &patternDict,
                    std::vector<std::pair<std::string, int> >& allWordPattern) {
    char ch;
    int i = 0;
    std::string tmpStr = "";
    bool  inWord = false;
    while ((ch = getchar()) != '\n') {

        if (ch == EOF) {
            return;
        }

        if (isdigit(ch)) {
            if (!inWord) {
                tmpStr += ch;
                inWord = true;
            } else {
                tmpStr += ch;
            }
        } else {
            if (patternDict.find(tmpStr) == patternDict.end()) {
                patternDict[tmpStr] = i;
                i++;
            }
            allWordPattern.push_back(std::pair<std::string, int>
                                             (tmpStr, patternDict[tmpStr]));
            tmpStr = "";
        }
    }
    if (tmpStr.size()) {
        if (patternDict.find(tmpStr) == patternDict.end()) {
            patternDict[tmpStr] = i;
        }
        allWordPattern.push_back(std::pair<std::string, int>
                                         (tmpStr, patternDict[tmpStr]));
    }
}